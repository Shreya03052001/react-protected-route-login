function GetPath(key){
    // This object stores page names and their corresponding URL paths.
    var keyValuePair={"Dashboard":"/db","Profile":"/profile"};
   
//    Uses the provided key to retrieve the corresponding path.
// For example, GetPath("Dashboard") returns /db.
    return keyValuePair[key];
}

export default GetPath;