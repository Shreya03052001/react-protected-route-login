import React from 'react'

function loggedInUserDetails() {
  return (
   
   <>
   <hr/>
   <h3>Welcome {userName}</h3>
   <button onClick={SignOut}> Sign</button>
   <hr/>
   
   </>
    
  )
}

export default loggedInUserDetails
