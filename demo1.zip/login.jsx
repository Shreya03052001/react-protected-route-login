import {useEffect, useState} from "react";
import {useNavigate} from "react-router-dom";
import GetPath from './getpath';

function Login() {

const naviagte=useNavigate();
const[credentials,setCredentials]=useEffect({UserName:"", Password: ""})
const[errorMessage,setErrorMessage]=useState("");

useEffect(()=>{
    if(errorMessage!="")
    {
        setTimeout(()=>{
            setErrorMessage("");

        },3000);
    }
},[errorMessage])

const OnTextChange=(args)=>{

    var copyOfCredentials={...credentials};
    copyOfCredentials[args.target.name]=args.target.value;
    setCredentials(copyOfCredentials);
}

const SignIn=()=>{
if(credentials.UserName=="abc" && credentials.Password=="abc@123")
{

    sessionStorage.setItem("UserName",credentials.UserName);
    sessionStorage.setItem("IsLoggedIn",true);
    var nextpage=sessionStorage.getItem("nextpage")
    var path=GetPath(nextpage);
    naviagte(path,{replace:"true"});
}else{

    setErrorMessage("Credentials are Invalid. Try again.")

}


}

  return (<>
  <h1>Sign In here</h1>
  <hr></hr>

  <table>
<tr>
    <td>User Name</td>
    <td>
        <input type="text" name="UserName" value={CredentialsContainer.UserName} onChange={OnTextChange}/>

    </td>
</tr>
<tr>
    <td>Password</td>
    <td>
        {/* we took type as password to hide the password */}
        <input type="password" name="UserName" value={CredentialsContainer.UserName} onChange={OnTextChange}/>
        
    </td>
</tr>
<tr>
    <td colSpan={2}>
        <button onClick={SignIn}>Sign In</button>

    </td>
</tr>

  </table>
  
 
<hr></hr>
<div style={{color:"red"}}>{errorMessage}

</div>

  </>  )
}

export default Login;
