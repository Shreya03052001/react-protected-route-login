import { Link,Route ,createRoutesFromChildren} from "react-router-dom";
import Home from './home';
import Contact from './contact';
import About from './about';
import NotFound from "./notfound";
import Dashboard from "./dashboard";
import ProtectedRoute from "./protectedRoute";
import Login from "./login";
import Profile from "./profile";


function Launcher() {
/*
Link is a React Router component.
to specifies the destination.
Clicking the link navigates to the Home page.

*/
    return (<>

        <hr></hr>
        <Link to={"home"}>Go Home</Link>  {"| "}
        <Link to={"about-us"}>About</Link>{" | "}
        <Link to={"contact-us"}>Contact</Link>{" | "}
        <Link to={"db"}>Dashboard</Link> {" | "}
        <Link to="profile">Profile</Link>{" | "}
        {/* <Link to={"login"}>Sign In</Link> {" | "}*/}
        <hr></hr>

        <Routes>
            {/* When the URL is /, React displays the Home component. */}
           {/* When the URL is /about-us, React displays the About component. */}
           {/* The Dashboard component is passed as a child to ProtectedRoute
            ProtectedRoute checks whether the user is logged in.
            If the user is logged in, Dashboard is displayed.
            Otherwise, the user is redirected to Login. */}
            <Route path="/" element={<Home />} />
            <Route path="/home" element={<Home />} />
            <Route path="/contact-us" element={<Contact />} />
            <Route path="/about-us" element={<About />} />
            <Route path="/db" element={<ProtectedRoute>
                <Dashboard />
            </ProtectedRoute>
            } />
            <Route path="/profile" element={<ProtectedRoute>
                <Profile />
            </ProtectedRoute>
            } />

            < Route path="/login" element={<Login />} />
            <Route path="*" element={<NotFound />} />

         {/* * is a wildcard route.
         It matches URLs that do not match any other defined route.
         It displays the NotFound component. */}
        </Routes>

    </>

    )
}
export default Launcher;