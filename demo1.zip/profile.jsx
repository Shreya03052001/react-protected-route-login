import React from 'react'

function profile() {
  return (<>
  <LoggedInUserDetails/>
  <h1>Change Your Profile Details Here</h1>
  
  </>);
}

export default profile
