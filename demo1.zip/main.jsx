//react-dom/client connects React with the browser DOM.
//createRoot() creates a React root where the application will be rendered.
//
import {createRoot} from 'react-dom/client'
import {BrowserRouter} from 'react-router-dom'
import Launcher from './launcher'


createRoot(document.getElementById('root')).render(
  <BrowserRouter>
  <Launcher/>
  </BrowserRouter>

)
